import jwt from "jsonwebtoken";
import { User } from "../../models/user.models.js";
import { ApiError } from "../utils/api-error.js";

export const authenticate = async (req, res, next) => {
  try {
    // Minimal debug: indicate presence of auth header / cookie keys without logging secrets
    const hasAuthHeader = !!req.headers.authorization;
    const cookieKeys = req.cookies ? Object.keys(req.cookies) : [];
    console.log(`auth debug -> hasAuthHeader=${hasAuthHeader}, cookieKeys=[${cookieKeys.join(",")} ]`);

    const token = req.cookies.accessToken || req.headers.authorization?.split(" ")[1];
    console.log(`auth debug -> tokenPresent=${!!token}, tokenLength=${token? token.length : 0}, hasSecret=${!!process.env.ACCESS_TOKEN_SECRET}`);

    if (!token) {
      throw new ApiError(401, "Unauthorized request");
    }

    const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);

    const user = await User.findById(decoded._id).select("-password -refreshToken");

    if (!user) {
      throw new ApiError(401, "Unauthorized request");
    }

    req.user = user; // Attach user to request
    next();
  } catch (error) {
    console.error("Token validation error:", error.message);
    next(new ApiError(401, "Invalid access token"));
  }
};

// Export the same function with different names for compatibility
export const verifyJWT = authenticate;
