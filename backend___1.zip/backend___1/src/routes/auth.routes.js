import { Router } from "express";

import { registerUser } from "../controllers/auth.controllers.js";

import { login } from "../controllers/auth.controllers.js";

import { validate } from "../middlewares/validator.middleware.js";

import { verifyJWT, authenticate } from "../middlewares/auth.middleware.js";

import {
  userLoginValidator,
  userRegisteredValidator,
  userForgotPasswordValidator,
  userResetForgotPasswordValidator,
} from "../validators/index.js";

import { logoutUser } from "../controllers/auth.controllers.js";

import { verifyEmail } from "../controllers/auth.controllers.js";

import { refreshAccessToken } from "../controllers/auth.controllers.js";

import {
  resetForgotPassword,
  deleteUserByEmail,
  forgotPasswordRequest,
  getCurrentUser,
  deleteAllUsers,
  resendEmailVerification,
} from "../controllers/auth.controllers.js";

const router = Router();

//flow----> we collect all the errors in userRegisteredValidator()----> pass it onto the middleware( validate ), if its ok good, if not it throws a error -----> then it reaches the registerUser

//unsecure routes
router
  .route("/register")
  .post(userRegisteredValidator(), validate, registerUser);

router.route("/login").post(userLoginValidator(), validate, login);

router.route("/verify-email/:verificationToken").get(verifyEmail);

router.route("/refresh-token").post(refreshAccessToken);

router
  .route("/forgot-password")
  .post(userForgotPasswordValidator(), validate, forgotPasswordRequest);

router
  .route("/reset-password")
  .post(userResetForgotPasswordValidator(), validate, resetForgotPassword);

//secure routes
router.route("/logout").post(verifyJWT, logoutUser);

router.route("/current-user").get(authenticate, getCurrentUser);

router.route("/resend-email-verification").post(authenticate, resendEmailVerification);

// Testing route - delete user by email (remove in production)
router.route("/delete-user").delete(deleteUserByEmail);

// Testing route - delete all users (remove in production)
router.route("/delete-all").delete(deleteAllUsers);

export default router;
