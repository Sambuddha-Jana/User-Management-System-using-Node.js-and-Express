const asyncHandler = (requestHandler) =>{
    return (req,res,next) =>{

        Promise
        .resolve(requestHandler(req,res,next))
        .catch((err) => next(err))
        //automatically handles all the error and passes to express's inbuilt error handler
    }
}


export {asyncHandler}