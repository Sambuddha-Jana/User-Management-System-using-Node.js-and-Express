import { body } from "express-validator";

//Part2---> validation part done
const userRegisteredValidator = () => {
  return [
    body("email")
      .trim()
      .notEmpty()
      .withMessage("Email is required")
      .isEmail()
      .withMessage("Email is invalid"),

    body("username")
      .trim()
      .notEmpty()
      .withMessage("Username is required")
      .withMessage("Username must be in lowercase")
      .isLength({ min: 3 })
      .withMessage("Username must be atleast 3 characters long"),

    body("password").trim().notEmpty().withMessage("Password is required"),

    body("fullname").optional().trim(),

    //part3-->part 3 in routes in auth.routes for linking the part1 and part2 of the middlewrr
  ];
};

const userLoginValidator = () => {
  return [
    body("email").optional().isEmail().withMessage("Email is invalid"),
    body("username").optional().trim(),
    body("password").notEmpty().withMessage("Password is required"),
    // Custom validation to ensure at least email or username is provided
    body().custom((value, { req }) => {
      if (!req.body.email && !req.body.username) {
        throw new Error("Either email or username is required");
      }
      return true;
    }),
  ];
};

const userChangeCurrentPassword = () => {
  return [
    body("oldPassword").notEmpty().withMessage("Old password is required"),
    body("newPassword").notEmpty().withMessage("New password is required"),
  ];
};

const userForgotPasswordValidator = () => {
  return [
    body("email")
      .notEmpty()
      .withMessage("Email is required")
      .isEmail()
      .withMessage("Email is valid"),
  ];
};

const userResetForgotPasswordValidator = () => {
  return [
    body("password").notEmpty().withMessage("Password is required"),
    body("token").notEmpty().withMessage("Reset token is required"),
  ];
};

export {
  userRegisteredValidator,
  userLoginValidator,
  userChangeCurrentPassword,
  userForgotPasswordValidator,
  userResetForgotPasswordValidator,
};
