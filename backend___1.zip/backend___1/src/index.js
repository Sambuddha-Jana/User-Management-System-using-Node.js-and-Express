import dotenv from "dotenv";

import app from "./app.js";

import connectDB from "./db/dbconnection.js";

dotenv.config({
  path: "./.env",
});

// let myusername = process.env.database

// console.log("value: ",myusername);

// console.log("Start of the backend project");

// import express from "express"; not needed now since importing separately in the app.js

const port = process.env.PORT || 8000;

// app.get("/", (req, res) => {
//   res.send("Hello World!");
// });

// app.get("/instagram",(req,res)=>{
//     res.send("this is an instagram page")
// })

// // app.listen(port, () => {
// //   console.log(`Example app listening on port http://localhost:${port}`);
// // });
//  paste this inside the connectDb method

connectDB()
  .then(() => {
    app.listen(port, () => {
      console.log(`Example app listening on port http://localhost:${port}`);
    });
  })
  .catch((error) => {
    console.error("MongoDb connection error", error);
    process.exit(1);
  });
