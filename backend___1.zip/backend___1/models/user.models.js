import mongoose, { Schema } from "mongoose";
import bcrypt from "bcrypt"; // ✅ fixed typo: was 'brcypt'
import jwt from "jsonwebtoken";
import crypto from "crypto";

// Define User Schema
const userSchema = new Schema(
  {
    // Avatar field with default placeholder
    avatar: {
      type: {
        url: String,
        localPath: String,
      },
      default: {
        url: "https://placehold.co/200x200", // ✅ added quotes around URL
        localPath: "",
      },
    },

    // Username field
    username: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      index: true,
    },

    // Email field
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },

    // Full name field
    fullName: {
      type: String,
      trim: true,
    },

    // Password field
    password: {
      type: String,
      required: [true, "Password is required"],
    },

    // Email verification status
    isEmailVerified: {
      type: Boolean,
      default: false,
    },

    // Refresh token
    refreshToken: {
      type: String,
    },

    // Forgot password token + expiry
    forgotPasswordToken: {
      type: String,
    },
    forgotPasswordExpiry: {
      type: Date, // ✅ fixed: was "Data"
    },

    // Email verification token + expiry
    emailVerificationToken: {
      type: String,
    },
    emailVerificationExpiry: {
      type: Date, // ✅ fixed: was "Data"
    },
  },
  {
    timestamps: true, // ✅ adds createdAt and updatedAt automatically
  },
);

// Hash password before saving
userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();

  this.password = await bcrypt.hash(this.password, 10); // ✅ fixed: was 'brcypt'
  next();
});

// Check if password is correct
userSchema.methods.isPasswordCorrect = async function (password) {
  return await bcrypt.compare(password, this.password);
};

// Generate Access Token
userSchema.methods.generateAccessToken = function () {
  return jwt.sign(
    {
      _id: this._id,
      email: this.email,
      username: this.username,
    },
    process.env.ACCESS_TOKEN_SECRET,
    { expiresIn: process.env.ACCESS_TOKEN_EXPIRY },
  );
};

// Generate Refresh Token
userSchema.methods.generateRefreshToken = function () {
  return jwt.sign(
    {
      _id: this._id,
    },
    process.env.REFRESH_TOKEN_SECRET,
    { expiresIn: process.env.REFRESH_TOKEN_EXPIRY },
  );
};

// Generate Temporary Token (e.g. for password reset or email verification)
userSchema.methods.generateTemporaryToken = function () {
  const unHashedToken = crypto.randomBytes(20).toString("hex");

  const hashedToken = crypto
    .createHash("sha256")
    .update(unHashedToken)
    .digest("hex");

  const tokenExpiry = Date.now() + 20 * 60 * 1000; // 20 mins
  return { unHashedToken, hashedToken, tokenExpiry };
};

// Export User model
export const User = mongoose.model("User", userSchema);
